// import fetch from 'node-fetch';
const express = require("express");
const app = express()
const userSearch = require('./routes/search')
app.use(express.urlencoded({ extended: true }))

app.set('view engine', 'ejs')

const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

app.use("/search", userSearch)

// app.get("/searh", async function(req,res))

app.listen(3000)